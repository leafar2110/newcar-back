<?php

require_once 'includes/legacy_hooks.php';
require_once 'includes/package.php';