<div class="notice notice-warning wpgmza-open-layers-feature-unavailable" style="display: none;">
	<p>
		<?php
		_e('This feature is not available when using the OpenLayers engine. Please go to settings then select and configure Google Maps to enable this feature.', 'wp-google-maps');
		?>
	</p>
</div>