<div class="ncpost">

        <?php the_post_thumbnail('mid-thumbnail');?>

        <div class="n-down">
            <div class="title">
                <h4><?php the_title(); ?></h4>
            </div>
            <div class="btn-holder text-center">

                    <a href="<?php the_permalink(); ?>"> Leer mas</a>

            </div>
        </div>
</div>
